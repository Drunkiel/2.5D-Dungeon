using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(
    fileName = "GridTerrainData",
    menuName = "GridTerrain/Terrain Data")]
public class GridTerrainDataAsset : ScriptableObject
{
    public Mesh mesh;
    public List<TileDataSerialized> tiles = new();
}

[System.Serializable]
public struct TileDataSerialized
{
    public Vector2Int position;
    public string tileId;
}
