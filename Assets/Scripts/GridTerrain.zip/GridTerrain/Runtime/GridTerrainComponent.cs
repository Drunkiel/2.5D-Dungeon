#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class GridTerrainComponent : MonoBehaviour
{
    public GridTerrainDataAsset terrainAsset;
    public GridTerrainData runtimeData = new();

    public MeshFilter meshFilter;

    void OnEnable()
    {
        meshFilter = GetComponent<MeshFilter>();
        Load();
    }

    public void Save()
    {
#if UNITY_EDITOR
        if (terrainAsset == null)
        {
            Debug.LogError("GridTerrainComponent.Save: terrainAsset is NULL");
            return;
        }

        if (meshFilter == null)
            meshFilter = GetComponent<MeshFilter>();

        // 1️⃣ Save tiles
        terrainAsset.tiles.Clear();
        foreach (var kv in runtimeData.AllTiles())
        {
            terrainAsset.tiles.Add(new TileDataSerialized
            {
                position = kv.Key,
                tileId = kv.Value.tileId
            });
        }

        // 2️⃣ Save / overwrite mesh
        if (meshFilter.sharedMesh != null)
        {
            if (terrainAsset.mesh == null)
            {
                terrainAsset.mesh = Instantiate(meshFilter.sharedMesh);
                terrainAsset.mesh.name = terrainAsset.name + "_Mesh";

                AssetDatabase.AddObjectToAsset(
                    terrainAsset.mesh,
                    terrainAsset
                );
            }
            else
            {
                EditorUtility.CopySerialized(
                    meshFilter.sharedMesh,
                    terrainAsset.mesh
                );
            }
        }

        EditorUtility.SetDirty(terrainAsset);
        EditorUtility.SetDirty(terrainAsset.mesh);
        AssetDatabase.SaveAssets();

        Debug.Log("GridTerrain saved (mesh reused)");
#endif
    }

    void Load()
    {
        if (terrainAsset == null)
            return;

        if (meshFilter == null)
            meshFilter = GetComponent<MeshFilter>();

        runtimeData.Clear();
        foreach (var t in terrainAsset.tiles)
        {
            runtimeData.SetTile(
                t.position,
                new TileData { tileId = t.tileId }
            );
        }

        if (terrainAsset.mesh != null)
            meshFilter.sharedMesh = terrainAsset.mesh;
    }

#if UNITY_EDITOR
    public void ForceLoadFromAsset()
    {
        // if (savedTerrainAsset == null)
        // {
        //     Debug.LogError("No terrain asset assigned");
        //     return;
        // }

        // if (!EditorUtility.DisplayDialog(
        //     "Force Load Terrain",
        //     "This will OVERWRITE current terrain data and mesh.\n\nUnsaved changes will be LOST.\n\nAre you sure?",
        //     "Load",
        //     "Cancel"))
        //     return;

        // // Tiles
        // Load();

        // // Mesh
        // var meshComp = GetComponent<GridTerrainMesh>();
        // if (meshComp != null && savedTerrainAsset.mesh != null)
        //     meshComp.TryLoadSavedMesh();

        // Debug.Log("Terrain loaded from asset");
    }
#endif

}
