using System.Collections.Generic;
using UnityEngine;

[ExecuteAlways]
[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class GridTerrainMesh : MonoBehaviour
{
    public Mesh mesh;

    void EnsureMeshReference()
    {
        var mf = GetComponent<MeshFilter>();

        if (mf.sharedMesh != null)
        {
            mesh = mf.sharedMesh;
            return;
        }

        mesh = new Mesh
        {
            name = "GridTerrain_Runtime"
        };
        mf.sharedMesh = mesh;
    }

    public Mesh GetMesh()
    {
        EnsureMeshReference();
        return mesh;
    }

    public void Build(GridTerrainData sourceData)
    {
        if (sourceData == null)
            return;

        EnsureMeshReference();

        if ((sourceData.tiles == null || sourceData.tiles.Count == 0)
            && mesh != null
            && mesh.vertexCount > 0)
        {
            print($"{sourceData.tiles == null}, {sourceData.tiles.Count == 0}, {mesh != null}, {mesh.vertexCount > 0}");
            return;
        }

        List<Vector3> vertices = new();
        List<int> triangles = new();
        List<Vector2> uvs = new();

        foreach (var kvp in sourceData.AllTiles())
        {
            AddTile(
                kvp.Key,
                kvp.Value,
                sourceData,
                vertices,
                triangles,
                uvs
            );
        }

        mesh.Clear();
        mesh.SetVertices(vertices);
        mesh.SetTriangles(triangles, 0);
        mesh.SetUVs(0, uvs);
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();
    }

    void AddTile(
        Vector2Int cell,
        TileData tile,
        GridTerrainData data,
        List<Vector3> vertices,
        List<int> triangles,
        List<Vector2> uvs)
    {
        if (string.IsNullOrEmpty(tile.tileId))
            return;

        var ruleTile = TileDatabase.GetRuleTile(tile.tileId);
        if (ruleTile == null)
            return;

        var sprite = RuleTileAdapter.ResolveSprite(ruleTile, cell, data);
        if (sprite == null)
            return;

        SpriteUV.Get(sprite, out Vector2 uvMin, out Vector2 uvMax);

        float size = data.asset.cellSize / 2f;

        // 🔥 NOWY SYSTEM WYSOKOŚCI (warstwowy)
        float worldHeight = tile.height * data.tileHeight;

        int vIndex = vertices.Count;

        Vector3 center = new Vector3(
            cell.x * size + size / 2f,
            worldHeight,
            cell.y * size + size / 2f
        );

        Quaternion rot = Quaternion.Euler(tile.rotation);

        Vector3[] quad =
        {
        new Vector3(-size/2, 0, -size/2),
        new Vector3(size/2, 0, -size/2),
        new Vector3(size/2, 0, size/2),
        new Vector3(-size/2, 0, size/2),
    };

        float minY = float.MaxValue;
        Vector3[] rotated = new Vector3[4];

        for (int i = 0; i < 4; i++)
        {
            rotated[i] = rot * quad[i];

            if (rotated[i].y < minY)
                minY = rotated[i].y;
        }

        Vector3 snapOffset = Vector3.zero;

        // 🔥 SNAP DO POZIOMU WARSTWY
        if (data.autoSnapHeight)
        {
            snapOffset = new Vector3(0, -minY, 0);
        }

        for (int i = 0; i < 4; i++)
        {
            vertices.Add(center + rotated[i] + snapOffset);
        }

        triangles.Add(vIndex + 0);
        triangles.Add(vIndex + 2);
        triangles.Add(vIndex + 1);

        triangles.Add(vIndex + 0);
        triangles.Add(vIndex + 3);
        triangles.Add(vIndex + 2);

        uvs.Add(new Vector2(uvMin.x, uvMin.y));
        uvs.Add(new Vector2(uvMax.x, uvMin.y));
        uvs.Add(new Vector2(uvMax.x, uvMax.y));
        uvs.Add(new Vector2(uvMin.x, uvMax.y));
    }

}